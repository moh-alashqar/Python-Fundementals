# Warning: DEPRECATED

Please use the repo for my book, available here: https://github.com/shantnu/PyEng
